<?php
session_start();
include '../koneksi.php';

if (isset($_POST['login'])) {
    $username = $_POST['username'];
    $password = ($_POST['password']);

    $query = mysqli_query($conn, "SELECT * FROM admin WHERE username='$username' AND password='$password'");
    if (mysqli_num_rows($query) > 0) {
        $_SESSION['admin'] = $username;
        header("Location: dashboard.php");
    } else {
        $error = "Username atau Password salah!";
    }
}
?>

<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <title>Login Admin</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            background-color: #e8f0ea;
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
        }

        .login-container {
            background-color: #0b4e2c;
            color: white;
            padding: 40px;
            border-radius: 12px;
            box-shadow: 0 0 15px rgba(0,0,0,0.2);
            width: 320px;
        }

        h2 {
            margin-bottom: 25px;
            font-size: 24px;
            text-align: center;
            color: #ffffff;
        }

        input[type="text"],
        input[type="password"] {
            width: 90%;
            padding: 12px;
            margin-bottom: 20px;
            border: none;
            border-radius: 8px;
            background-color: #ffffff;
            color: #000;
            font-size: 14px;
        }

        button {
            width: 100%;
            padding: 12px;
            background-color: #f4c542;
            color: #000;
            font-weight: bold;
            border: none;
            border-radius: 8px;
            cursor: pointer;
            transition: background-color 0.3s;
        }

        button:hover {
            background-color: #e0b83e;
        }

        .error {
            background-color: #ffcccc;
            color: red;
            padding: 10px;
            border-radius: 6px;
            margin-bottom: 15px;
            font-size: 14px;
            text-align: center;
        }

        footer {
            position: absolute;
            bottom: 15px;
            text-align: center;
            width: 100%;
            font-size: 12px;
            color: #777;
        }
    </style>
</head>
<body>

<div class="login-container">
    <h2>Login Admin</h2>
    <?php if (!empty($error)) echo "<div class='error'>$error</div>"; ?>
    <form method="post">
        <input type="text" name="username" placeholder="Username" required>
        <input type="password" name="password" placeholder="Password" required>
        <button type="submit" name="login">Login</button>
        <div style="text-align: center; margin-top: 10px;">
            <a href="../index.php" style="color: white; text-decoration: none;">Kembali</a>
        </div>
    </form>
</div>

<footer>&copy; 2025 Monitoring Harga Pangan</footer>

</body>
</html>
