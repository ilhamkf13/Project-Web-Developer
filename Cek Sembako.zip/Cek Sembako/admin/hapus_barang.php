<?php
include '../koneksi.php';

$id = $_GET['id'];

// Ambil gambar lama
$data = mysqli_fetch_assoc(mysqli_query($conn, "SELECT gambar FROM barang WHERE id='$id'"));
$gambar = $data['gambar'];

// Hapus dari database
$query = mysqli_query($conn, "DELETE FROM barang WHERE id='$id'");

if ($query) {
  // Hapus gambar juga
  if (file_exists("../uploads/" . $gambar)) {
    unlink("../uploads/" . $gambar);
  }

  echo "<script>alert('Data berhasil dihapus!'); window.location='list_barang.php';</script>";
} else {
  echo "Gagal menghapus data.";
}
