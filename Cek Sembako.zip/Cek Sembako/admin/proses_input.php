<?php
include '../koneksi.php'; // sesuaikan path jika beda

// Ambil data dari form
$nama        = $_POST['nama'];
$harga       = $_POST['harga'];
$distributor = $_POST['distributor'];
$kontak      = $_POST['kontak'];

// Upload gambar
$nama_file   = $_FILES['gambar']['name'];
$tmp_file    = $_FILES['gambar']['tmp_name'];
$upload_dir  = '../uploads/'; // pastikan folder ini sudah ada dan writable

// Buat nama unik untuk file (biar ga bentrok)
$nama_baru = time() . '_' . basename($nama_file);
$target_path = $upload_dir . $nama_baru;

// Cek dan pindahkan file
if (move_uploaded_file($tmp_file, $target_path)) {
    // Simpan ke database
    $query = "INSERT INTO barang (nama, harga, distributor, kontak, gambar)
              VALUES ('$nama', '$harga', '$distributor', '$kontak', '$nama_baru')";

    $result = mysqli_query($conn, $query);

    if ($result) {
        echo "<script>alert('Data berhasil disimpan!'); window.location='dashboard.php';</script>";
    } else {
        echo "Gagal menyimpan ke database: " . mysqli_error($conn);
    }

} else {
    echo "Gagal mengupload gambar.";
}
?>
