<?php
include '../koneksi.php';

$id          = $_POST['id'];
$nama        = $_POST['nama'];
$harga       = $_POST['harga'];
$distributor = $_POST['distributor'];
$kontak      = $_POST['kontak'];
$gambar_lama = $_POST['gambar_lama'];

$nama_file   = $_FILES['gambar']['name'];
$tmp_file    = $_FILES['gambar']['tmp_name'];
$upload_dir  = '../uploads/';

if (!empty($nama_file)) {
    // User upload gambar baru
    $nama_baru = time() . '_' . basename($nama_file);
    $target_path = $upload_dir . $nama_baru;

    if (move_uploaded_file($tmp_file, $target_path)) {
        // Hapus gambar lama
        if (file_exists($upload_dir . $gambar_lama)) {
            unlink($upload_dir . $gambar_lama);
        }

        // Update dengan gambar baru
        $query = "UPDATE barang SET 
                    nama = '$nama',
                    harga = '$harga',
                    distributor = '$distributor',
                    kontak = '$kontak',
                    gambar = '$nama_baru'
                  WHERE id = '$id'";
    } else {
        echo "Upload gambar gagal.";
        exit;
    }
} else {
    // Tanpa upload gambar baru
    $query = "UPDATE barang SET 
                nama = '$nama',
                harga = '$harga',
                distributor = '$distributor',
                kontak = '$kontak'
              WHERE id = '$id'";
}

$result = mysqli_query($conn, $query);

if ($result) {
    echo "<script>alert('Data berhasil diupdate!'); window.location='list_barang.php';</script>";
} else {
    echo "Gagal update: " . mysqli_error($conn);
}
?>
