<?php
include '../koneksi.php';

$id = $_GET['id'];
$query = mysqli_query($conn, "SELECT * FROM barang WHERE id = '$id'");
$data = mysqli_fetch_assoc($query);
?>

<!DOCTYPE html>
<html>
<head>
  <title>Update Barang</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f0f4f8;
      margin: 0;
    }

    .container {
      max-width: 600px;
      margin: 60px auto;
      background-color: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 12px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #024731;
      margin-bottom: 25px;
    }

    label {
      display: block;
      margin-bottom: 6px;
      font-weight: 600;
    }

    input[type="text"],
    input[type="number"],
    input[type="file"] {
      width: 100%;
      padding: 10px;
      margin-bottom: 16px;
      border: 1px solid #ccc;
      border-radius: 8px;
      box-sizing: border-box;
    }

    img {
      max-width: 150px;
      margin-bottom: 10px;
      display: block;
    }

    button {
      width: 100%;
      padding: 12px;
      background-color: #028b55;
      color: white;
      font-weight: bold;
      border: none;
      border-radius: 8px;
      cursor: pointer;
    }

    button:hover {
      background-color: #026f44;
    }

    .back {
      margin-top: 15px;
      text-align: center;
    }

    .back a {
      color: #024731;
      text-decoration: none;
      font-weight: bold;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Update Data Barang</h2>
  <form method="post" action="proses_update.php" enctype="multipart/form-data">
    <input type="hidden" name="id" value="<?= $data['id']; ?>">
    <input type="hidden" name="gambar_lama" value="<?= $data['gambar']; ?>">

    <label>Nama Barang</label>
    <input type="text" name="nama" value="<?= $data['nama']; ?>" required>

    <label>Harga (Rp)</label>
    <input type="number" name="harga" value="<?= $data['harga']; ?>" required>

    <label>Distributor</label>
    <input type="text" name="distributor" value="<?= $data['distributor']; ?>" required>

    <label>Kontak</label>
    <input type="text" name="kontak" value="<?= $data['kontak']; ?>" required>

    <label>Gambar Sekarang:</label>
    <img src="../uploads/<?= $data['gambar']; ?>" alt="Gambar Barang">

    <label>Upload Gambar Baru (opsional)</label>
    <input type="file" name="gambar" accept="image/*">

    <button type="submit">Simpan Perubahan</button>
  </form>

  <div class="back">
    <a href="dashboard.php">← Kembali ke Dashboard</a>
  </div>
</div>

</body>
</html>
