<?php
include '../koneksi.php';
?>

<!DOCTYPE html>
<html>
<head>
  <title>Daftar Barang</title>
  <style>
    body {
      font-family: 'Segoe UI', sans-serif;
      background-color: #f4f7fa;
      margin: 0;
    }

    .container {
      max-width: 900px;
      margin: 40px auto;
      background-color: white;
      padding: 30px;
      border-radius: 12px;
      box-shadow: 0 4px 10px rgba(0,0,0,0.1);
    }

    h2 {
      text-align: center;
      color: #024731;
      margin-bottom: 25px;
    }

    table {
      width: 100%;
      border-collapse: collapse;
      margin-top: 20px;
    }

    th, td {
      padding: 12px;
      border: 1px solid #ccc;
      text-align: center;
    }

    th {
      background-color: #024731;
      color: white;
    }

    img {
      max-height: 80px;
    }

    a.button {
      display: inline-block;
      padding: 6px 12px;
      color: white;
      text-decoration: none;
      border-radius: 5px;
      font-weight: bold;
    }

    .edit {
      background-color: #3498db;
    }

    .hapus {
      background-color: #e74c3c;
    }

    .back {
      margin-top: 20px;
      text-align: center;
    }

    .back a {
      text-decoration: none;
      font-weight: bold;
      color: #024731;
    }
  </style>
</head>
<body>

<div class="container">
  <h2>Daftar Barang Sembako</h2>

  <table>
    <thead>
      <tr>
        <th>No</th>
        <th>Gambar</th>
        <th>Nama</th>
        <th>Harga</th>
        <th>Distributor</th>
        <th>Kontak</th>
        <th>Aksi</th>
      </tr>
    </thead>
    <tbody>
      <?php
      $no = 1;
      $query = mysqli_query($conn, "SELECT * FROM barang");
      while ($row = mysqli_fetch_assoc($query)) {
      ?>
      <tr>
        <td><?= $no++; ?></td>
        <td><img src="../uploads/<?= $row['gambar']; ?>" alt="gambar"></td>
        <td><?= $row['nama']; ?></td>
        <td>Rp <?= number_format($row['harga'], 0, ',', '.'); ?></td>
        <td><?= $row['distributor']; ?></td>
        <td><?= $row['kontak']; ?></td>
        <td>
          <a href="update.php?id=<?= $row['id']; ?>" class="button edit">Edit</a>
          <a href="hapus_barang.php?id=<?= $row['id']; ?>" class="button hapus" onclick="return confirm('Yakin ingin hapus data ini?')">Hapus</a>
        </td>
      </tr>
      <?php } ?>
    </tbody>
  </table>

  <div class="back">
    <a href="dashboard.php">← Kembali ke Dashboard</a>
  </div>
</div>

</body>
</html>
