<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit;
}
?>

<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Admin</title>
    <style>
        body {
            font-family: 'Segoe UI', sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f0f4f8;
        }

        .navbar {
            background-color: #0b4e2c;
            color: white;
            padding: 15px;
            text-align: center;
            font-size: 24px;
        }

        .container {
            max-width: 800px;
            margin: 40px auto;
            background-color: white;
            padding: 30px;
            border-radius: 10px;
            box-shadow: 0 4px 10px rgba(0,0,0,0.1);
        }

        h2 {
            color: #0b4e2c;
            text-align: center;
            margin-bottom: 20px;
        }

        .menu {
            display: flex;
            flex-direction: column;
            gap: 15px;
        }

        .menu a {
            display: block;
            background-color: #0b4e2c;
            color: white;
            text-align: center;
            padding: 12px;
            text-decoration: none;
            border-radius: 6px;
            font-weight: bold;
            transition: background-color 0.3s;
        }

        .menu a:hover {
            background-color: #0b4e2c;
        }

        .logout {
            margin-top: 30px;
            text-align: center;
        }

        .logout a {
            color: #c0392b;
            text-decoration: none;
            font-weight: bold;
        }

        .logout a:hover {
            text-decoration: underline;
        }
    </style>
</head>
<body>

<div class="navbar">
    Panel Admin - Cek Sembako
</div>

<div class="container">
    <h2>Selamat Datang, <?php echo $_SESSION['admin']; ?>!</h2>

    <div class="menu">
        <a href="input.php">➕ Input Barang</a>
        <a href="list_barang.php">💸 Update Harga</a>
        <a href="../index.php">🌐 Lihat Halaman Utama</a>
    </div>

    <div class="logout">
        <a href="logout.php">Keluar</a>
    </div>
</div>

</body>
</html>
