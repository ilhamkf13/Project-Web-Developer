<html>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="icon" type="image/png" href="assets/Sandy_F&D-04_Single-02.jpg">
    <title>Monitoring Harga Pangan</title>
    <script src="https://cdn.tailwindcss.com"></script>
    <link rel="stylesheet" href=link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;600&display=swap">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <style>
        .btn-home {
            background-color: #ffffff;
            color: #000;
            text-decoration: none;
            padding: 12px 24px;
            margin: 10px;
            border-radius: 10px;
            font-weight: bold;
            font-size: 16px;
            display: inline-block;
            transition: background-color 0.3s ease;
        }
    
        .btn-home:hover {
            background-color: #0b4e2c;
        }
    </style>

</head>
<body class="bg-gray-100 font-poppins">
    <!-- Navbar -->
    <nav class="bg-green-900 text-white p-4 flex justify-between items-center fixed top-0 left-0 w-full shadow-md z-50">
        <div class="flex items-center">
            <img src="assets/logo.jpg" alt="Logo" class="rounded-full mr-4" width="40" height="40">
            <span class="text-xl font-bold">Monitoring Harga Pangan</span>
        </div>
        <ul class="flex space-x-4">
            <li><a href="#home" class="hover:underline">Home</a></li>
            <li><a href="#news" class="hover:underline">News</a></li>
            <li><a href="#contact" class="hover:underline">Contact</a></li>
        </ul>
    </nav>
    

    <!-- Hero Section -->
    <main class="pt-10 mt-5 p-0">
    <section id="home" class="bg-green-900 text-white p-8 flex flex-col md:flex-row items-center">
        <img src="assets/logo.jpg" alt="A bowl of fresh vegetables" class="rounded-full w-1/2 md:w-1/3 mb-4 md:mb-0" width="200" height="200">
        <div class="md:ml-8 text-center md:text-left">
            <h1 class="text-3xl font-bold mb-4">Selamat Datang di Monitoring Harga Pangan</h1>
            <div style="text-align: center; margin-top: 20px;">
                <a href="admin/login.php" class="btn-home">🔒 Login Admin</a>
                <a href="search/indexsearch.php" class="btn-home">🔍 Cari Harga</a>
            </div>
        </div>
    </section>

    <!-- Main Content -->
    <main class="p-8">
        <h2 class="text-2xl font-bold text-center mb-8">Pantau Ketersediaan & Harga Bahan Pangan Dengan Mudah</h2>

        <!-- News Section -->
        <section id="news">
        <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-8">
            <div class="bg-green-900 text-white p-4 rounded-md flex items-center cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-lg">
                <div class="flex-grow">
                    <h3 class="font-bold">BISNIS JATENG</h3>
                    <p>Stok Bawang Merah Melimpah Sumbang Deflasi di Jawa Tengah</p>
                    <p class="text-sm">6 Days ago</p>
                </div>
                <img src="assets/berita bawang.jpg" alt="Market scene with onions" class="rounded-md ml-4" width="200" height="100">
            </div>            
            <div class="bg-green-900 text-white p-4 rounded-md flex items-center cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-lg">
                <div class="flex-grow">
                    <h3 class="font-bold">BISNIS JAKARTA</h3>
                    <p>Jelang HBKN Gubernur Pramono Pantau Ketersediaan Pangan dan harga Komoditas Stabil </p>
                    <p class="text-sm">6 Days ago</p>
                </div>
                <img src="assets/IMG-20250310-WA0153 (1).jpg" alt="Market scene with onions" class="rounded-md ml-4" width="200" height="100">
            </div>
            <div class="bg-green-900 text-white p-4 rounded-md flex items-center cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-lg">
                <div class="flex-grow">
                    <h3 class="font-bold">BISNIS JATENG</h3>
                    <p>PT PPI Bantu Ketersediaan Pangan dengan Harga Terjangkau</p>
                    <p class="text-sm">6 Days ago</p>
                </div>
                <img src="assets/a_67cead070a1e9 (1).jpeg" alt="Market scene with onions" class="rounded-md ml-4" width="200" height="100">
            </div>
            <div class="bg-green-900 text-white p-4 rounded-md flex items-center cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-lg">
                <div class="flex-grow">
                    <h3 class="font-bold">JAKARTA</h3>
                    <p>Wamentan ajak Pemda rutin sidak pasar jaga ketersediaan pangan</p>
                    <p class="text-sm">6 Days ago</p>
                </div>
                <img src="assets/B7422241-4FA2-475C-B0AB-76BC029F4459.jpeg (1).webp" alt="Market scene with onions" class="rounded-md ml-4" width="200" height="100">
            </div>
            <div class="bg-green-900 text-white p-4 rounded-md flex items-center cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-lg">
                <div class="flex-grow">
                    <h3 class="font-bold">BISNIS JATENG</h3>
                    <p>Stok Bawang Merah Melimpah Sumbang Deflasi di Jawa Tengah</p>
                    <p class="text-sm">6 Days ago</p>
                </div>
                <img src="assets/berita bawang.jpg" alt="Market scene with onions" class="rounded-md ml-4" width="200" height="100">
            </div>
            <div class="bg-green-900 text-white p-4 rounded-md flex items-center cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-lg">
                <div class="flex-grow">
                    <h3 class="font-bold">BISNIS JAKARTA</h3>
                    <p>Jelang HBKN Gubernur Pramono Pantau Ketersediaan Pangan dan harga Komoditas Stabil </p>
                    <p class="text-sm">6 Days ago</p>
                </div>
                <img src="assets/IMG-20250310-WA0153 (1).jpg" alt="Market scene with onions" class="rounded-md ml-4" width="200" height="100">
            </div>
            <div class="bg-green-900 text-white p-4 rounded-md flex items-center cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-lg">
                <div class="flex-grow">
                    <h3 class="font-bold">JAKARTA</h3>
                    <p>Wamentan ajak Pemda rutin sidak pasar jaga ketersediaan pangan</p>
                    <p class="text-sm">6 Days ago</p>
                </div>
                <img src="assets/B7422241-4FA2-475C-B0AB-76BC029F4459.jpeg (1).webp" alt="Market scene with onions" class="rounded-md ml-4" width="200" height="100">
            </div>
            <div class="bg-green-900 text-white p-4 rounded-md flex items-center cursor-pointer transition-transform duration-200 hover:scale-105 hover:shadow-lg">
                <div class="flex-grow">
                    <h3 class="font-bold">BISNIS JATENG</h3>
                    <p>PT PPI Bantu Ketersediaan Pangan dengan Harga Terjangkau</p>
                    <p class="text-sm">6 Days ago</p>
                </div>
                <img src="assets/a_67cead070a1e9 (1).jpeg" alt="Market scene with onions" class="rounded-md ml-4" width="200" height="100">
            </div>
        </div>
        </section>
        <!-- About Section -->
        <section id="contact" class="bg-green-900 text-white p-8 rounded-md text-center">
            <h2 class="text-2xl font-bold mb-4">Tentang Kami</h2>
            <p class="mb-6">
                Kami adalah platform monitoring harga pangan yang bertujuan 
                untuk memberikan informasi harga bahan pangan secara real-time, akurat, 
                dan terpercaya. Dengan data yang terus diperbarui, kami membantu 
                masyarakat dalam mengambil keputusan terbaik saat berbelanja kebutuhan pokok.
            </p>        
            <div class="bg-green-900 text-white text-center p-4">
                <div class="flex justify-center space-x-8">
                    <a href="#"><i class="fab fa-twitter mr-1"></i> CekSembakoID</a>
                    <a href="#"><i class="fab fa-facebook mr-1"></i> CekSembakoID</a>
                    <a href="#"><i class="fab fa-instagram mr-1"></i> CekSembakoID</a>
                </div>
                <p class="mt-2"><i class="fas fa-envelope mr-1"></i> ceksembakoid@gmail.com</p>
            </div>
        </section>
    </main>

    <!-- Footer -->
    <footer class="bg-green-900 text-white text-center p-4">
        <p>2025 All Right Reserved</p>
    </footer>
</body>
</html>